#include "stdafx.h"


struct LINETHREADINFO
{
	int LineNumber;
};